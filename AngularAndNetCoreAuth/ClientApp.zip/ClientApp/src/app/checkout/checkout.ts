export class Checkout{
  constructor(
    public Id: string,
    public Name: string,
  ) {}

}
