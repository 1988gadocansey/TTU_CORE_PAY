export class Product{
  constructor(
    public Id: string,
    public Name: string,
  ) {}

}
